package com.web.book.version;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VersionApplicationTests {

	@Test
	void contextLoads() {
	}

}
