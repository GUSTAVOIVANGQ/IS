package com.web.book.version.repository;

public class BookRepository {

}
