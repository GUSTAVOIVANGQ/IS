package com.web.book.version.model;

public enum RoleType {
    ADMIN,
    USER,
    MODERATOR
}