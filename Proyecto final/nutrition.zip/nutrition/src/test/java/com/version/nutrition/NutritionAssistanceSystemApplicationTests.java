package com.version.nutrition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionAssistanceSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
