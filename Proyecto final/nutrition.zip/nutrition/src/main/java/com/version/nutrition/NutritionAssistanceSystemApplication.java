package com.version.nutrition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutritionAssistanceSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutritionAssistanceSystemApplication.class, args);
	}

}
