package com.version.nutrition.dto;

public class RegistroDTO {

}
